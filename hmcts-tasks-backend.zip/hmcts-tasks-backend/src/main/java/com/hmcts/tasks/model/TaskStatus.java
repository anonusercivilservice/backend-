package com.hmcts.tasks.model;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE,
    BLOCKED
}
